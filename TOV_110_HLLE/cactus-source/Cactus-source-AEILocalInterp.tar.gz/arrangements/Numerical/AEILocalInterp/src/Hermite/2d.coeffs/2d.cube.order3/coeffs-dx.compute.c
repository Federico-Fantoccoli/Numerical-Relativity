fp t616;
fp t618;
fp t648;
fp t617;
fp t647;
fp t646;
fp t645;
fp t644;
fp t635;
fp t608;
fp t548;
fp t643;
fp t551;
fp t642;
fp t597;
fp t567;
fp t610;
fp t628;
fp t540;
fp t641;
fp t577;
fp t640;
fp t607;
fp t631;
fp t539;
fp t592;
fp t639;
fp t627;
fp t580;
fp t638;
fp t579;
fp t637;
fp t636;
fp t634;
fp t633;
fp t535;
fp t578;
fp t632;
fp t630;
fp t588;
fp t520;
fp t629;
fp t626;
fp t583;
fp t564;
fp t612;
fp t625;
fp t624;
fp t591;
fp t563;
fp t623;
fp t611;
fp t622;
fp t621;
fp t614;
fp t576;
fp t620;
fp t615;
fp t613;
fp t609;
fp t606;
fp t605;
fp t604;
fp t603;
fp t602;
fp t601;
fp t600;
fp t599;
fp t598;
fp t595;
fp t594;
fp t593;
fp t589;
fp t587;
fp t586;
fp t585;
fp t584;
fp t575;
fp t574;
fp t573;
fp t572;
fp t571;
fp t570;
fp t568;
fp t566;
fp t565;
fp t562;
fp t560;
fp t559;
fp t558;
fp t557;
fp t556;
fp t553;
fp t552;
fp t550;
fp t547;
fp t544;
fp t543;
fp t542;
fp t536;
fp t534;
fp t532;
fp t524;
fp t522;
fp t521;
fp t519;
      t616 = y*y;
      t618 = t616*y;
      t648 = x*t618;
      t617 = x*x;
      t647 = t617*y;
      t646 = y+t618;
      t645 = x*t616;
      t644 = t617*t616;
      t635 = t617*t618;
      t608 = RATIONAL(7.0,3.0);
      t548 = t608*t635;
      t643 = t548+t608*t645;
      t551 = RATIONAL(-7.0,3.0)*t635;
      t642 = RATIONAL(-35.0,6.0)*t645+t551;
      t597 = RATIONAL(7.0,18.0);
      t567 = t597*t618;
      t610 = RATIONAL(1.0,3.0);
      t628 = t617*t610;
      t540 = t618*t628;
      t641 = t540+RATIONAL(7.0,9.0)*t645;
      t577 = RATIONAL(5.0,18.0);
      t640 = t577*t645+t540;
      t607 = RATIONAL(-1.0,3.0);
      t631 = t607*t617;
      t539 = t618*t631;
      t592 = RATIONAL(-7.0,18.0);
      t639 = t592*t645+t539;
      t627 = t617*RATIONAL(-1.0,48.0);
      t580 = RATIONAL(-1.0,36.0);
      t638 = t618*t627+t580*t645;
      t579 = RATIONAL(1.0,48.0);
      t637 = t579*t617;
      t636 = RATIONAL(-70.0,9.0)*t645+RATIONAL(-16.0,3.0)*t635;
      t634 = t616*RATIONAL(-5.0,12.0);
      t633 = RATIONAL(7.0,48.0)*t617;
      t535 = t618*t633;
      t578 = RATIONAL(5.0,24.0);
      t632 = t578*t645+t535;
      t630 = RATIONAL(-7.0,48.0)*t617;
      t588 = RATIONAL(-1.0,12.0);
      t520 = t618*t630;
      t629 = t520+t588*t645;
      t626 = x*t646;
      t583 = RATIONAL(-1.0,18.0);
      t564 = t583*y;
      t612 = RATIONAL(-5.0,3.0);
      t625 = t551+t564+t612*t645;
      t624 = t564+t520+x*t634;
      t591 = RATIONAL(1.0,18.0);
      t563 = t591*y;
      t623 = t563+RATIONAL(-49.0,48.0)*t635+RATIONAL(-5.0,4.0)*t645;
      t611 = RATIONAL(-4.0,9.0);
      t622 = RATIONAL(25.0,6.0)*t645+t548+t611*y;
      t621 = t563+t539+RATIONAL(-5.0,9.0)*t645;
      t614 = RATIONAL(1.0,6.0);
      t576 = RATIONAL(-1.0,144.0);
      t620 = t535+t576*y+t614*t645;
      t615 = RATIONAL(4.0,9.0);
      t613 = RATIONAL(-2.0,3.0);
      t609 = RATIONAL(-2.0,9.0);
      t606 = RATIONAL(2.0,9.0);
      t605 = RATIONAL(-1.0,9.0);
      t604 = RATIONAL(2.0,3.0);
      t603 = RATIONAL(1.0,9.0);
      t602 = RATIONAL(1.0,72.0);
      t601 = RATIONAL(-5.0,24.0);
      t600 = RATIONAL(-7.0,12.0);
      t599 = RATIONAL(-1.0,24.0);
      t598 = RATIONAL(1.0,12.0);
      t595 = RATIONAL(-7.0,36.0);
      t594 = RATIONAL(1.0,24.0);
      t593 = RATIONAL(10.0,3.0);
      t589 = RATIONAL(-5.0,18.0);
      t587 = RATIONAL(7.0,12.0);
      t586 = RATIONAL(7.0,36.0);
      t585 = RATIONAL(-1.0,72.0);
      t584 = RATIONAL(1.0,36.0);
      t575 = RATIONAL(1.0,144.0);
      t574 = t603*t618;
      t573 = t615*y;
      t572 = RATIONAL(-8.0,9.0)*t618;
      t571 = RATIONAL(8.0,9.0)*t618;
      t570 = t605*t618;
      t568 = t591*t618;
      t566 = t592*t618;
      t565 = t583*t618;
      t562 = t576*t618;
      t560 = RATIONAL(-7.0,144.0)*t618;
      t559 = RATIONAL(7.0,144.0)*t618;
      t558 = t575*y;
      t557 = t575*t618;
      t556 = y*t631;
      t553 = RATIONAL(7.0,6.0)*t647;
      t552 = RATIONAL(-1.0,6.0)*t647;
      t550 = RATIONAL(-8.0,3.0)*t647;
      t547 = RATIONAL(8.0,3.0)*t647;
      t544 = RATIONAL(-7.0,6.0)*t647;
      t543 = t614*t647;
      t542 = y*t628;
      t536 = y*t633;
      t534 = y*t627;
      t532 = RATIONAL(16.0,3.0)*t635;
      t524 = t579*t635;
      t522 = y*t630;
      t521 = y*t637;
      t519 = RATIONAL(49.0,48.0)*t635;
      coeffs_dx->coeff_m2_m2 = t558+t521+t557+t524+(t599*t617+t585)*t616+(t591*
t616+t646*t580)*x;
      coeffs_dx->coeff_m1_m2 = t522+t565+(RATIONAL(7.0,24.0)*t617+t603)*t616+
t578*t626+t624;
      coeffs_dx->coeff_0_m2 = t613*t644+t542+t592*t626+t641;
      coeffs_dx->coeff_p1_m2 = t568+t556+(t605+t604*t617)*t616+t577*t626+t621;
      coeffs_dx->coeff_p2_m2 = t562+t536+(t602+RATIONAL(-7.0,24.0)*t617)*t616+
t588*t626+t620;
      coeffs_dx->coeff_p3_m2 = t534+t594*t644+t602*t626+t638;
      coeffs_dx->coeff_m2_m1 = t560+t552+(RATIONAL(5.0,48.0)+RATIONAL(5.0,16.0)
*t617)*t616+(t606*y+t586*t618)*x+t624;
      coeffs_dx->coeff_m1_m1 = t567+t553+t573+t519+(RATIONAL(-35.0,16.0)*t617+
RATIONAL(-5.0,6.0))*t616+(RATIONAL(-35.0,24.0)*t618+t612*y+RATIONAL(25.0,8.0)*
t616)*x;
      coeffs_dx->coeff_0_m1 = RATIONAL(5.0,1.0)*t644+t550+(RATIONAL(49.0,18.0)*
t618+RATIONAL(28.0,9.0)*y)*x+t642;
      coeffs_dx->coeff_p1_m1 = t547+t566+(RATIONAL(-5.0,1.0)*t617+RATIONAL(5.0,
6.0))*t616+(RATIONAL(-20.0,9.0)*y+RATIONAL(-35.0,18.0)*t618)*x+t622;
      coeffs_dx->coeff_p2_m1 = t544+t559+(RATIONAL(35.0,16.0)*t617+RATIONAL(
-5.0,48.0))*t616+(t587*t618+t604*y)*x+t623;
      coeffs_dx->coeff_p3_m1 = t543+RATIONAL(-5.0,16.0)*t644+(t605*y+RATIONAL(
-7.0,72.0)*t618)*x+t632;
      coeffs_dx->coeff_m2_0 = t595*t616+t574+t598+(t600*t616+RATIONAL(1.0,4.0))
*t617+(t611*t618+t607)*x+t641;
      coeffs_dx->coeff_m1_0 = t613+t572+RATIONAL(14.0,9.0)*t616+(RATIONAL(-7.0,
4.0)+RATIONAL(49.0,12.0)*t616)*t617+(RATIONAL(5.0,2.0)+t593*t618)*x+t642;
      coeffs_dx->coeff_0_0 = t532+(RATIONAL(-28.0,3.0)*t616+RATIONAL(4.0,1.0))*
t617+(RATIONAL(-14.0,3.0)+RATIONAL(-56.0,9.0)*t618+RATIONAL(98.0,9.0)*t616)*x;
      coeffs_dx->coeff_p1_0 = t571+t604+RATIONAL(-14.0,9.0)*t616+(RATIONAL(-4.0
,1.0)+RATIONAL(28.0,3.0)*t616)*t617+(RATIONAL(40.0,9.0)*t618+t593)*x+t636;
      coeffs_dx->coeff_p2_0 = t570-x+t588+RATIONAL(-4.0,3.0)*t648+t586*t616+(
RATIONAL(-49.0,12.0)*t616+RATIONAL(7.0,4.0))*t617+t643;
      coeffs_dx->coeff_p3_0 = (t587*t616+RATIONAL(-1.0,4.0))*t617+(t606*t618+
t614)*x+t639;
      coeffs_dx->coeff_m2_p1 = t543+t570+(RATIONAL(5.0,12.0)*t617+RATIONAL(5.0,
36.0))*t616+(t615*t618+t609*y)*x+t621;
      coeffs_dx->coeff_m1_p1 = t571+t544+(RATIONAL(-35.0,12.0)*t617+RATIONAL(
-10.0,9.0))*t616+(RATIONAL(5.0,3.0)*y+RATIONAL(-10.0,3.0)*t618)*x+t622;
      coeffs_dx->coeff_0_p1 = t547+RATIONAL(20.0,3.0)*t644+(RATIONAL(56.0,9.0)*
t618+RATIONAL(-28.0,9.0)*y)*x+t636;
      coeffs_dx->coeff_p1_p1 = t550+t572+t573+t532+(RATIONAL(-20.0,3.0)*t617+
RATIONAL(10.0,9.0))*t616+(RATIONAL(20.0,9.0)*y+RATIONAL(50.0,9.0)*t616+RATIONAL
(-40.0,9.0)*t618)*x;
      coeffs_dx->coeff_p2_p1 = t574+t553+(RATIONAL(35.0,12.0)*t617+RATIONAL(
-5.0,36.0))*t616+(t613*y+RATIONAL(4.0,3.0)*t618)*x+t625;
      coeffs_dx->coeff_p3_p1 = t552+t617*t634+(t603*y+t609*t618)*x+t640;
      coeffs_dx->coeff_m2_p2 = t559+t534+(t599+RATIONAL(-1.0,8.0)*t617)*t616+(
t584*y+t595*t618)*x+t620;
      coeffs_dx->coeff_m1_p2 = t536+t566+(t610+RATIONAL(7.0,8.0)*t617)*t616+(
RATIONAL(35.0,24.0)*t618+t601*y)*x+t623;
      coeffs_dx->coeff_0_p2 = t556+RATIONAL(-2.0,1.0)*t644+(RATIONAL(-49.0,18.0
)*t618+t597*y)*x+t643;
      coeffs_dx->coeff_p1_p2 = t542+t567+(t607+RATIONAL(2.0,1.0)*t617)*t616+(
t589*y+RATIONAL(35.0,18.0)*t618)*x+t625;
      coeffs_dx->coeff_p2_p2 = t522+t558+t560+t519+(t594+RATIONAL(-7.0,8.0)*
t617)*t616+(t600*t618+RATIONAL(1.0,2.0)*t616+t598*y)*x;
      coeffs_dx->coeff_p3_p2 = t521+RATIONAL(1.0,8.0)*t644+(t585*y+RATIONAL(7.0
,72.0)*t618)*x+t629;
      coeffs_dx->coeff_m2_p3 = t562+t584*t648+(t575+t637)*t616+t638;
      coeffs_dx->coeff_m1_p3 = t601*t648+t568+(t583+t630)*t616+t632;
      coeffs_dx->coeff_0_p3 = t616*t628+x*t567+t639;
      coeffs_dx->coeff_p1_p3 = t565+t589*t648+(t631+t591)*t616+t640;
      coeffs_dx->coeff_p2_p3 = t557+t598*t648+(t633+t576)*t616+t629;
      coeffs_dx->coeff_p3_p3 = t524+t616*t627+(t585*t618+t602*t616)*x;
