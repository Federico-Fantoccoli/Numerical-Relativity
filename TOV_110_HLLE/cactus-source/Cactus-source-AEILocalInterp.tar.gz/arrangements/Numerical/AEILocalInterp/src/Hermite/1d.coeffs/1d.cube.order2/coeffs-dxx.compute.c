      coeffs_dxx->coeff_m1 = RATIONAL(2.0,1.0)+RATIONAL(-3.0,1.0)*x;
      coeffs_dxx->coeff_0 = RATIONAL(-5.0,1.0)+RATIONAL(9.0,1.0)*x;
      coeffs_dxx->coeff_p1 = RATIONAL(-9.0,1.0)*x+RATIONAL(4.0,1.0);
      coeffs_dxx->coeff_p2 = RATIONAL(-1.0,1.0)+RATIONAL(3.0,1.0)*x;
