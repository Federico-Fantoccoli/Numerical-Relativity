fp t9;
fp t8;
      t9 = RATIONAL(-1.0,2.0);
      t8 = RATIONAL(1.0,2.0);
      coeffs_dx->coeff_0_0 = t9;
      coeffs_dx->coeff_p1_0 = t8;
      coeffs_dx->coeff_0_p1 = t9;
      coeffs_dx->coeff_p1_p1 = t8;
