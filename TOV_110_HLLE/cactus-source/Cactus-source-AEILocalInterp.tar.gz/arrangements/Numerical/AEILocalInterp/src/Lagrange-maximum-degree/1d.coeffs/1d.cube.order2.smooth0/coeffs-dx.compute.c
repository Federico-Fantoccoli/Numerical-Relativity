      coeffs_dx->coeff_m1 = x+RATIONAL(-1.0,2.0);
      coeffs_dx->coeff_0 = RATIONAL(-2.0,1.0)*x;
      coeffs_dx->coeff_p1 = RATIONAL(1.0,2.0)+x;
