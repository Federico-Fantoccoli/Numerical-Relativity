fp t11;
fp t10;
      t11 = RATIONAL(-1.0,2.0);
      t10 = RATIONAL(1.0,2.0);
      coeffs_dy->coeff_0_0 = t11;
      coeffs_dy->coeff_p1_0 = t11;
      coeffs_dy->coeff_0_p1 = t10;
      coeffs_dy->coeff_p1_p1 = t10;
