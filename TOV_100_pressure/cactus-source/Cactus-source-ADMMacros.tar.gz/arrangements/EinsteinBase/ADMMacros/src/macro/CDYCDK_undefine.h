/*@@
  @header   CDYCDK_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CDYCDK_GUTS

#include "DYDK_undefine.h"
#include "CHR2_undefine.h"

