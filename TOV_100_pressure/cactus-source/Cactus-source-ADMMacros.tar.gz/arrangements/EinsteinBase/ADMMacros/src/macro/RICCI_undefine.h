/*@@
  @header   RICCI_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef RICCI_GUTS

#include "UPPERMET_undefine.h"
#include "DDG_undefine.h"
#include "CHR1_undefine.h"
#include "CHR2_undefine.h"
