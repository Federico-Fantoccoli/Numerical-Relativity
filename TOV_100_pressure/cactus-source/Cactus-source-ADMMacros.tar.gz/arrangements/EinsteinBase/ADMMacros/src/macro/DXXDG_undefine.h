/*@@
  @header   DXXDG_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DXXDG_GUTS

#include "DXDG_undefine.h"
