#ifndef LIMITS_HH
#define LIMITS_HH

#include <cctk.h>

namespace CarpetLib {

void set_system_limits();

} // namespace CarpetLib

#endif // #ifndef LIMITS_HH
